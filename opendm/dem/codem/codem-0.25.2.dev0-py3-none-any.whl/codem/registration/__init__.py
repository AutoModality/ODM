from .apply import ApplyRegistration
from .dsm import DsmRegistration
from .icp import IcpRegistration
